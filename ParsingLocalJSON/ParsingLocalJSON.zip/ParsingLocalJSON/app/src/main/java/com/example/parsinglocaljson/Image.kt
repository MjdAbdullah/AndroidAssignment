package com.example.parsinglocaljson

data class Image(val url: String)

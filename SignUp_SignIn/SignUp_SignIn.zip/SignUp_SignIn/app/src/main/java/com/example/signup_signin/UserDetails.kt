package com.example.signup_signin

data class UserDetails(
    val Name: String,
    val Email: String,
    val Phone: String,
    val Password: String
    )
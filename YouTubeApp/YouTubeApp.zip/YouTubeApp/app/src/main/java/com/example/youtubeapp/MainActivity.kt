package com.example.youtubeapp

import android.content.Context
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var ytPlayer: YouTubePlayerView
    var VideoList = arrayListOf<Video>()
    lateinit var player: YouTubePlayer
    var t = 0.0f
    var indx = 0
    var id = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Perform an internet connection
        val cm = this.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork: NetworkInfo? = cm.activeNetworkInfo
        activeNetwork?.isConnectedOrConnecting
        if (activeNetwork?.isConnectedOrConnecting == true) {
            Toast.makeText(this, "Connected To The Internet", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Not Connected To The Internet", Toast.LENGTH_LONG).show()
        }

        val rvMain = findViewById<RecyclerView>(R.id.rvMain)
        ytPlayer = findViewById(R.id.youtube_player_view)
        getLifecycle().addObserver(ytPlayer)

        VideoList.add(Video("CiFyTc1SwPw", "Numbers Game"))
        VideoList.add(Video("ZbZFMDk69IA", "Calculator"))
        VideoList.add(Video("DU1qMhyKv8g", "Guess the Phrase"))
        VideoList.add(Video("G_XYXuC8b9M", "Username and Password"))
        VideoList.add(Video("sqJWyPhZkDw", "GUI Username and Password"))
        VideoList.add(Video("yBkRLhoVTmc", "Country Capitals"))
        VideoList.add(Video("E-Kb6FgMbVw", "Database Module"))

        ytPlayer.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                super.onReady(youTubePlayer)
                player = youTubePlayer
                rvMain.adapter = RecyclerViewAdapter(this@MainActivity, VideoList, player)
                rvMain.layoutManager = LinearLayoutManager(this@MainActivity)
            }
        })
    }
    //----------------------------------------------------------------------------------------------
    //Preserve the state
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putFloat("time",VideoList[indx].time)
        outState.putString("Id",VideoList[indx].ID)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        id = savedInstanceState.getString("Id") as String
        t = savedInstanceState.getFloat("time")

    }
    //----------------------------------------------------------------------------------------------
    //Preserve the state
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (newConfig.orientation === Configuration.ORIENTATION_LANDSCAPE) {
            ytPlayer.exitFullScreen()
        } else if (newConfig.orientation === Configuration.ORIENTATION_PORTRAIT) {
            ytPlayer.enterFullScreen()
        }
    }
}
//----------------------------------------------------------------------------------------------
// class video
class Video(val ID: String, val Name :String){
    var time = 0.0f
}
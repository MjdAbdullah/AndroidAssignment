package com.example.todoapp

class Item(val item : String  , var Check : Boolean){
}
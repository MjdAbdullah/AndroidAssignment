package com.example.firebase_recipeapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    val db = Firebase.firestore
    val TAG = "MainActivity"
    lateinit var rvMain : RecyclerView
    var arr = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etTitle = findViewById<TextView>(R.id.etTitle)
        val etAuthor = findViewById<TextView>(R.id.etAuthor)
        val etIngredents = findViewById<TextView>(R.id.etIngredents)
        val etInstruction = findViewById<TextView>(R.id.etInstruction)
        val bSave = findViewById<Button>(R.id.bSave)
        val bView = findViewById<Button>(R.id.bView)
        rvMain = findViewById(R.id.rvMain)

        bSave.setOnClickListener {
            if(etTitle.text.isNotEmpty() && etAuthor.text.isNotEmpty() && etIngredents.text.isNotEmpty()
                && etInstruction.text.isNotEmpty()){
                var recipe = hashMapOf(
                    ("Title" to etTitle.text.toString()),
                    ("Author" to etAuthor.text.toString()),
                    ("Ingredents" to etIngredents.text.toString()),
                    ("Instruction" to etInstruction.text.toString())
                )
                db.collection("recipe")
                    .add(recipe)
                    .addOnSuccessListener{
                            DocumentReference ->
                        Log.d(TAG, "DocumentSnapshot added with ID: " + DocumentReference.getId())
                    }

                    .addOnFailureListener{ e ->
                        Log.w(TAG, "Error adding document", e)
                    }
                Toast.makeText(this,"Save it",Toast.LENGTH_SHORT).show()
            }
        }

        bView.setOnClickListener {
            getData()
        }
        rvMain.adapter = RVAdapter(arr, this)
        rvMain.layoutManager = LinearLayoutManager(this)
    }
    fun getData(){
        db.collection("recipe")
            .get()
            .addOnSuccessListener { result ->
                arr.clear()
                for (document in result) {
                    var s = document.data.toString()
                    Log.d(TAG, "${document.id} => ${document.data} ${s}")
                    arr.add(s)
                }
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error read document", e)
            }

        rvMain.adapter?.notifyDataSetChanged()
    }
}
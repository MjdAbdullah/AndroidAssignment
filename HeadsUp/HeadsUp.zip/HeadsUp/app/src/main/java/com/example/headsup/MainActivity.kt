package com.example.headsup

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Surface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.isVisible
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.Main
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Exception
import java.net.URL

class MainActivity : AppCompatActivity() {
    lateinit var tvName: TextView
    lateinit var tvT1: TextView
    lateinit var tvT2: TextView
    lateinit var tvT3: TextView
    lateinit var lMain: LinearLayout
    lateinit var lC: LinearLayout

    lateinit var tvTime: TextView
    lateinit var tvMain: TextView
    lateinit var bStart: Button

    var on = false
    var celebrities= arrayListOf<JSONObject>()

    var num = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lMain = findViewById(R.id.lMain)
        lC = findViewById(R.id.lC)

        tvTime = findViewById(R.id.tvTime)

        tvName = findViewById(R.id.tvName)
        tvT1 = findViewById(R.id.tvT1)
        tvT2 = findViewById(R.id.tvT2)
        tvT3 = findViewById(R.id.tvT3)

        tvMain = findViewById(R.id.tvMain)
        bStart = findViewById(R.id.bStart)
        bStart.setOnClickListener {
            API()
        }
    }
    private fun API(){
        CoroutineScope(Dispatchers.IO).launch {
            var api = ""
            try {
                var api = URL("https://dojo-recipes.herokuapp.com/celebrities/")
                    .readText(Charsets.UTF_8)
            }catch (e: Exception){
                println("Error: $e")
            }
            if(api.isNotEmpty()){
                withContext(Main){
                    parseJSON(api)
                    celebrities.shuffle()
                    newCelebrity(0)
                    Timer()
                }
            }else{

            }
        }
    }

    private fun Timer(){
        if(!on){
            on = true
            tvMain.text = "Please Rotate Device"
            bStart.isVisible = false
            val rotation = windowManager.defaultDisplay.rotation
            if(rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180){
                updateStatus(false)
            }else{
                updateStatus(true)
            }

            object : CountDownTimer(20000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    tvTime.text = "Time: ${millisUntilFinished / 1000}"
                }

                override fun onFinish() {
                    on = false
                    tvTime.text = "Time: --"
                    tvMain.text = "Heads Up!"
                    bStart.isVisible = true
                    updateStatus(false)
                }
            }.start()
        }
    }

    private fun newCelebrity(id: Int){
        if(id < celebrities.size){
            tvName.text = celebrities[id].getString("name")
            tvT1.text = celebrities[id].getString("taboo1")
            tvT2.text = celebrities[id].getString("taboo2")
            tvT3.text = celebrities[id].getString("taboo3")
        }
    }


    private suspend fun parseJSON(result: String){
        withContext(Dispatchers.Main){
            celebrities.clear()
            val arr = JSONArray(result)
            for(i in 0..arr.length()-1){
                celebrities.add(arr.getJSONObject(i))
            }
        }
    }

    private fun updateStatus(show: Boolean){
        if(show){
            lC.isVisible = true
            lMain.isVisible = false
        }else{
            lC.isVisible = false
            lMain.isVisible = true
        }
    }
    //---------------------------------------------------------------------------------------------
    //for ROTATION
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val rotation = windowManager.defaultDisplay.rotation
        if(rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180){
            if(on){
                num++
                newCelebrity(num)
                updateStatus(false)
            }else{
                updateStatus(false)
            }
        }else{
            if(on){
                updateStatus(true)
            }else{
                updateStatus(false)
            }
        }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("on", on)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        on = savedInstanceState.getBoolean("on", on)
    }
}
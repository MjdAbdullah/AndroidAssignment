package com.example.simplepostrequest

data class CustomPersonListItem(val name: String, val pk: Int)
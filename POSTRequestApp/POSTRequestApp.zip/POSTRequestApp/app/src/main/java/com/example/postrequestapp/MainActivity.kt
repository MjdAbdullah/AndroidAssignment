package com.example.postrequestapp

import android.app.ProgressDialog
import android.content.Intent
import retrofit2.Call
import retrofit2.Callback
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Response


class MainActivity : AppCompatActivity() {
    var arr = arrayListOf<String?>()
    lateinit var rvMain : RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewUsers()
        rvMain = findViewById(R.id.rvMain)

        var bAdd = findViewById<Button>(R.id.bAdd)
        bAdd.setOnClickListener {
            val intent = Intent(this,AddUsers::class.java)
            startActivity(intent)
        }

        var bUpdate = findViewById<Button>(R.id.bUpdate)
        bUpdate.setOnClickListener {
        }

    }

    fun ViewUsers(){
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.apply {
            setMessage("WAIT")
            show()
        }
        api?.getData()?.enqueue(object : Callback<List<Users.Datum>>{
            override fun onResponse(
                call: Call<List<Users.Datum>>,
                response: Response<List<Users.Datum>>,
            ) {
                for (recope in response.body()!!){
                    arr.add("${recope.id}\n${recope.name}\n${recope.location}")
                }
                rvMain.adapter = RecyclerViewAdapter(this@MainActivity,arr)
                rvMain.layoutManager = LinearLayoutManager(this@MainActivity)
                progressDialog.dismiss()
            }

            override fun onFailure(call: Call<List<Users.Datum>>, t: Throwable) {
                progressDialog.dismiss()
                Toast.makeText(this@MainActivity,"Error $t",Toast.LENGTH_LONG).show()
            }

        })
    }



}
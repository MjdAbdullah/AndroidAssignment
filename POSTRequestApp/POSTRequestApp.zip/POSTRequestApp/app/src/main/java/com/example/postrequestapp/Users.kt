package com.example.postrequestapp

import com.google.gson.annotations.SerializedName

class Users {
    var Data : List<Datum>? = null

    class Datum {
        @SerializedName("pk")
        var id: Int? = null

        @SerializedName("name")
        var name : String? = null

        @SerializedName("location")
        var location : String? = null

        constructor(id: Int?, name: String?, location: String?){
            this.id = id
            this.name = name
            this.location = location
        }
    }

}
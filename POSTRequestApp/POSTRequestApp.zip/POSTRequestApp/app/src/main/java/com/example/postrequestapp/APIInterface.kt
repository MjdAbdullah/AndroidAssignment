package com.example.postrequestapp

import retrofit2.Call
import retrofit2.http.*

interface APIInterface {
    @Headers("Content-Type: application/json")
    @GET("/test/")
    fun getData(): Call<List<Users.Datum>>

    @Headers("Content-Type: application/json")
    @POST("/test/")
    fun postData(@Body userData: Users.Datum): Call<Users>

    @Headers("Content-Type: application/json")
    @PUT("/test/{id}")
    fun updateData(@Path("id") id:Int, @Body userData: Users.Datum): Call<Users.Datum>

    @Headers("Content-Type: application/json")
    @PUT("/test/{id}")
    fun deleteData(@Path("id") id:Int): Call<Void>
}
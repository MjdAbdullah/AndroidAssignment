package com.example.postrequestapp

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddUsers : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_users)

        var bAddUsers = findViewById<Button>(R.id.bAddUser)
        var bDelete = findViewById<Button>(R.id.bDelete)
        var bView = findViewById<Button>(R.id.bView)
        var etId = findViewById<EditText>(R.id.etId)
        var etName = findViewById<EditText>(R.id.etName)
        var etLocation = findViewById<EditText>(R.id.etLocation)
        var id : String

        bView.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        bAddUsers.setOnClickListener {
            if (etId.text.isNotEmpty() && etName.text.isNotEmpty() && etLocation.text.isNotEmpty()){
                id = etId.text.toString()
                val UserInput = Users.Datum(id.toInt(),etName.text.toString(),etLocation.text.toString())
                Add(UserInput)
                Update(UserInput,id.toInt())
                etId.text.clear()
                etName.text.clear()
                etLocation.text.clear()
            }
            else{
                Toast.makeText(this@AddUsers,"Wrong input",Toast.LENGTH_LONG)
            }
        }

        bDelete.setOnClickListener {
            if (etId.text.isNotEmpty()){
                id = etId.text.toString()
                DeleteUser(id.toInt())
            }else{
                Toast.makeText(this@AddUsers,"The User ID is empty",Toast.LENGTH_LONG)
            }
        }
    }

    fun DeleteUser(Id: Int) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        val PD = ProgressDialog(this@AddUsers)
        PD.apply {
            setMessage("WAIT")
            show()
        }
        api?.deleteData(Id)?.enqueue(object : Callback<Void>{
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Complete Delete",Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Error $t",Toast.LENGTH_LONG).show()
            }

        })
    }
    fun Update(UserInput: Users.Datum, id: Int) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        val PD = ProgressDialog(this@AddUsers)
        PD.apply {
            setMessage("WAIT")
            show()
        }
        api?.updateData(id,UserInput)!!.enqueue(object : Callback<Users.Datum>{
            override fun onResponse(call: Call<Users.Datum>, response: Response<Users.Datum>) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Complete Update",Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Users.Datum>, t: Throwable) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Error $t",Toast.LENGTH_LONG).show()
            }

        })
    }

    fun Add(UserInput: Users.Datum) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        val PD = ProgressDialog(this@AddUsers)
        PD.apply {
            setMessage("WAIT")
            show()
        }
        api?.postData(UserInput)?.enqueue(object : Callback<Users>{
            override fun onResponse(call: Call<Users>, response: Response<Users>) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Complete",Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Users>, t: Throwable) {
                PD.dismiss()
                Toast.makeText(this@AddUsers,"Error $t",Toast.LENGTH_LONG).show()
            }

        })
    }
}
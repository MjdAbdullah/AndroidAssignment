package com.example.headsup2

data class CelebrityModel(
    val Name: String,
    val Taboo1: String,
    val Taboo2: String,
    val Taboo3: String
)

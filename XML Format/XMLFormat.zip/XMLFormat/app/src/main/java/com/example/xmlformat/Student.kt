package com.example.xmlformat

data class Student( var id: Int = 0 , var name: String? = null , var marks: Float = 0.toFloat())

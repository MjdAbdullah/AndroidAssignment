package com.example.getandpost_location

data class UserDetails(
    val pk : Int,
    val name : String,
    val location : String
)

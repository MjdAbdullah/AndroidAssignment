package com.example.flickrbrowserapp

data class Image(var Title : String , var Link : String)

package com.example.headsupprep

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Update : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var ID = 0
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        val bBack = findViewById<Button>(R.id.bBack)
        bBack.setOnClickListener {
        startActivity(Intent(this,MainActivity::class.java))
        }

        ID = intent.extras!!.getInt("ID", 0)

        val etName = findViewById<EditText>(R.id.etName2)
        val etT1 = findViewById<EditText>(R.id.etT11)
        val etT2 = findViewById<EditText>(R.id.etT22)
        val etT3 = findViewById<EditText>(R.id.etT33)

        val bDelete = findViewById<Button>(R.id.bDelete)
        val bUpdate = findViewById<Button>(R.id.bUpdate)
        bDelete.setOnClickListener{
            delete(ID)
        }
        bUpdate.setOnClickListener{
            UpdateCelebrity(ID,Celebrity(etName.text.toString(),etT1.text.toString(),etT2.text.toString(),
                   etT3.text.toString(),ID))
            etName.text.clear()
            etT1.text.clear()
            etT2.text.clear()
            etT3.text.clear()
        }

        val api = APIClient().getClient()?.create(APIInterface::class.java)
        api?.getCelebrity(ID)?.enqueue(object: Callback<Celebrity> {
            override fun onResponse(call: Call<Celebrity>, response: Response<Celebrity>) {
                val celebrity = response.body()!!
                etName.setText(celebrity.name)
                etT1.setText(celebrity.taboo1)
                etT2.setText(celebrity.taboo2)
                etT3.setText(celebrity.taboo3)
            }

            override fun onFailure(call: Call<Celebrity>, t: Throwable) {
                Toast.makeText(this@Update, "Something went wrong", Toast.LENGTH_LONG).show()
            }

        })
    }

    private fun delete(id: Int) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        api?.deleteCelebrity(id)?.enqueue(object : Callback<Void>{
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                Toast.makeText(this@Update, "Complete", Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Toast.makeText(this@Update, "Error $t", Toast.LENGTH_LONG).show()
            }

        })
    }

    fun UpdateCelebrity(ID: Int, UserInput: Celebrity) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        api?.updateCelebrity(ID ,UserInput)?.enqueue(object : Callback<Celebrity>{
            override fun onResponse(call: Call<Celebrity>, response: Response<Celebrity>) {
                Toast.makeText(this@Update, "Complete", Toast.LENGTH_LONG).show()
            }
            override fun onFailure(call: Call<Celebrity>, t: Throwable) {
                Toast.makeText(this@Update, "Error $t", Toast.LENGTH_LONG).show()
            }

        })
    }

}
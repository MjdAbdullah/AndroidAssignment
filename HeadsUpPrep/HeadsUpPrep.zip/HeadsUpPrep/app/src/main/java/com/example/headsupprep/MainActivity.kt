package com.example.headsupprep

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var rvMain : RecyclerView
    lateinit var rvAdapter : RecyclerViewAdapter
    var celebrities = arrayListOf<Celebrity>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMain = findViewById(R.id.rvMain)
        val bAdd = findViewById<Button>(R.id.bAdd)
        val bSubmit = findViewById<Button>(R.id.bSubmit)
        val etName = findViewById<EditText>(R.id.etName)

        bAdd.setOnClickListener {
            startActivity(Intent(this,AddCelebrity::class.java))
        }
        bSubmit.setOnClickListener {
            Submit(etName.text.toString())
        }

        rvAdapter = RecyclerViewAdapter(this,celebrities)
        rvMain.adapter = rvAdapter
        rvMain.layoutManager = LinearLayoutManager(this@MainActivity)
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this@MainActivity)
        progressDialog.apply {
            setMessage("WAIT")
            show()
        }
        api?.getData()?.enqueue(object : Callback<ArrayList<Celebrity>>{
            override fun onResponse(
                call: Call<ArrayList<Celebrity>>,
                response: Response<ArrayList<Celebrity>>,
            ) {
                progressDialog.dismiss()
                celebrities = response.body()!!
                rvAdapter.update(celebrities)
                Toast.makeText(this@MainActivity, "Complete", Toast.LENGTH_LONG).show()

            }
            override fun onFailure(call: Call<ArrayList<Celebrity>>, t: Throwable) {
                progressDialog.dismiss()
                Toast.makeText(this@MainActivity, "Error $t", Toast.LENGTH_LONG).show()
            }

        })
    }

    fun Submit(etName: String) {
        var ID = 0
        for(celebrity in celebrities){
            if(etName.capitalize() == celebrity.name){
                ID = celebrity.pk
                intent = Intent(applicationContext, Update::class.java)
                intent.apply {
                    putExtra("ID", ID)
                    startActivity(this)
                }
            }else{
                Toast.makeText(this, "Not found", Toast.LENGTH_LONG).show()
            }
        }
    }
}
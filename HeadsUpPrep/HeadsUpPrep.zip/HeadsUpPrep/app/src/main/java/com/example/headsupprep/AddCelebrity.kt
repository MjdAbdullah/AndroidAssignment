package com.example.headsupprep

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddCelebrity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_celebrity)

        val bAdd = findViewById<Button>(R.id.bAdd1)
        val bBack = findViewById<Button>(R.id.bBack)
        val etName = findViewById<EditText>(R.id.etName1)
        val etT1 = findViewById<EditText>(R.id.etT1)
        val etT2 = findViewById<EditText>(R.id.etT2)
        val etT3 = findViewById<EditText>(R.id.etT3)

        bAdd.setOnClickListener {
            if(etName.text.isNotEmpty() && etT1.text.isNotEmpty() && etT2.text.isNotEmpty() && etT3.text.isNotEmpty()){
                val UserInput = Celebrity(etName.text.toString(), etT1.text.toString(), etT2.text.toString(), etT3.text.toString(),0)
                addCelebrity(UserInput)
                etName.text.clear()
                etT1.text.clear()
                etT2.text.clear()
                etT3.text.clear()
            }else{
                Toast.makeText(this@AddCelebrity ,"Empty input", Toast.LENGTH_LONG)
            }
        }
        bBack.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }

    }

    private fun addCelebrity(UserInput: Celebrity) {
        val api = APIClient().getClient()?.create(APIInterface::class.java)
        api?.putData(UserInput)?.enqueue(object : Callback<Celebrity>{
            override fun onResponse(
                call: Call<Celebrity>,
                response: Response<Celebrity>,
            ) {
                Toast.makeText(this@AddCelebrity,"Complete",Toast.LENGTH_LONG).show()
            }

            override fun onFailure(call: Call<Celebrity>, t: Throwable) {
                Toast.makeText(this@AddCelebrity,"Error $t",Toast.LENGTH_LONG).show()
            }

        })
    }
}
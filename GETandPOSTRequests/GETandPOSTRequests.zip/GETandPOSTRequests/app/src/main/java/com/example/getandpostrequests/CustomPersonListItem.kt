package com.example.getandpostrequests

data class CustomPersonListItem(val name: String, val pk: Int)

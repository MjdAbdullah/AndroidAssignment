package com.example.notefull

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.SyncStateContract.Helpers.update
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.notefull.RVAdapter.*

class MainActivity : AppCompatActivity() {

    lateinit var rvMain : RecyclerView
    private val myVM by lazy { ViewModelProvider(this).get(MyVM::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myVM.getNotes().observe(this, {
            notes -> rvMain.adapter = RVAdapter(notes,this)
        })

        val bAdd = findViewById<Button>(R.id.bAdd)
        val etNote = findViewById<EditText>(R.id.etNote)
        rvMain = findViewById(R.id.rvMain)
        //UpdateList()
        bAdd.setOnClickListener {
            if (etNote.text.isNotEmpty()){
                myVM.addNote(etNote.text.toString())
                Toast.makeText(this,"Save it", Toast.LENGTH_SHORT).show()
                etNote.text.clear()
                etNote.clearFocus()
            }
        }

        rvMain.layoutManager =LinearLayoutManager(this)
    }

    fun AlertUpdate(SelectNote: Note){
        val i = SelectNote.Id
        val alert = AlertDialog.Builder(this)
        val L = LinearLayout(this)
        val etItem = EditText(this)
        L.orientation = LinearLayout.VERTICAL
        L.addView(etItem)

        alert.setTitle("New Item")
            .setView(L)
            .setPositiveButton("ADD"){
                    dialog,which -> myVM.editNote(i,etItem.text.toString())
            }
            .setNegativeButton("CANCEL"){
                    dialog,which -> dialog.cancel()
            }
            .show()

        //UpdateList()
    }


}
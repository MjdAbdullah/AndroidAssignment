package com.example.notefull

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var rvMain : RecyclerView
    lateinit var arr : List<Note>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bAdd = findViewById<Button>(R.id.bAdd)
        val etNote = findViewById<EditText>(R.id.etNote)
        rvMain = findViewById(R.id.rvMain)
        UpdateList()
        bAdd.setOnClickListener {
            if (etNote.text.isNotEmpty()){
                val v = Note(0, etNote.text.toString())
                NoteDatabase.getinstance(applicationContext).NoteDao().addNote(v)
                Toast.makeText(this,"Save it", Toast.LENGTH_SHORT).show()
                UpdateList()
                etNote.text.clear()
                etNote.clearFocus()
            }
        }
        rvMain.adapter = RecyclerViewAdapter(this , arr)
        rvMain.layoutManager =LinearLayoutManager(this)
    }
    fun UpdateList(){
        arr = NoteDatabase.getinstance(applicationContext).NoteDao().getNote()
        rvMain.adapter = RecyclerViewAdapter(this , arr)
    }
    fun DeleteNote(SelectNote: Note){
        NoteDatabase.getinstance(applicationContext).NoteDao().deleteNote(SelectNote)
        UpdateList()
    }
    fun UpdateNote(SelectNote: Note){
        NoteDatabase.getinstance(applicationContext).NoteDao().updateNpte(SelectNote)
    }

    fun AlertUpdate(SelectNote: Note){
        val i = SelectNote.Id
        val alert = AlertDialog.Builder(this)
        val L = LinearLayout(this)
        val etItem = EditText(this)
        L.orientation = LinearLayout.VERTICAL
        L.addView(etItem)

        alert.setTitle("New Item")
            .setView(L)
            .setPositiveButton("ADD"){
                    dialog,which -> UpdateNote(Note(i,etItem.text.toString()))
            }
            .setNegativeButton("CANCEL"){
                    dialog,which -> dialog.cancel()
            }
            .show()

        UpdateList()
    }


}